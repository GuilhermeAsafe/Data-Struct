#ifndef MOTOR_H
#define MOTOR_H

#include "Corrida.h" 

// --- Evento ---
enum TipoEvento {
    CHEGADA_PARADA
};

class Evento {
public:
    double tempo;      
    TipoEvento tipo;
    Corrida* corrida;
    int indiceTrecho; 

    Evento(double t, TipoEvento tp, Corrida* c, int indice);
    bool operator>(const Evento& outro) const;
};

// --- MinHeap ---
class MinHeap {
private:
    Evento** dados;
    int capacidade;
    int tamanho;

    void redimensionar();
    void heapifyUp(int index);
    void heapifyDown(int index);
    void swap(int i, int j);

    int getParent(int i) { return (i - 1) / 2; }
    int getLeftChild(int i) { return 2 * i + 1; }
    int getRightChild(int i) { return 2 * i + 2; }

public:
    MinHeap();
    ~MinHeap();
    void inserir(Evento* evento);
    Evento* removerMin();
    bool estaVazio() const;
};

// --- Escalonador ---
class Escalonador {
private:
    MinHeap heap;

public:
    Escalonador();  
    ~Escalonador(); 

    void InsereEvento(Evento* evento);
    Evento* RetiraProximoEvento();
    bool estaVazio() const;
};

#endif // MOTOR_H