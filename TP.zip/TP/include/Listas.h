#ifndef LISTAS_H
#define LISTAS_H

#include "Dominio.h" // Precisa da definição completa de Trecho e Parada

class Corrida; // OK usar declaração antecipada (só usamos ponteiro)

// --- Lista de Demandas ---
struct NoDemanda {
    Demanda* dado; 
    NoDemanda* proximo;
    NoDemanda(Demanda* d);
};
class ListaDemanda {
private:
    NoDemanda* inicio; NoDemanda* fim; int tamanho;
public:
    ListaDemanda(); ~ListaDemanda();
    void push_back(Demanda* d); Demanda* get(int index);
    Demanda* pop_back(); int size() const; bool empty() const; void clear(); 
};

// --- Lista de Trechos ---
struct NoTrecho {
    Trecho dado; // Por VALOR. Requer #include "Dominio.h"
    NoTrecho* proximo;
    NoTrecho(Trecho t);
};
class ListaTrecho {
private:
    NoTrecho* inicio; NoTrecho* fim; int tamanho;
public:
    ListaTrecho(); ~ListaTrecho();
    void push_back(Trecho t); Trecho& get(int index);
    int size() const; bool empty() const; void clear(); 
};

// --- Lista de Paradas ---
struct NoParada {
    Parada dado; // Por VALOR. Requer #include "Dominio.h"
    NoParada* proximo;
    NoParada(Parada p);
};
class ListaParada {
private:
    NoParada* inicio; NoParada* fim; int tamanho;
public:
    ListaParada(); ~ListaParada();
    void push_back(Parada p); Parada* get(int index);
    int size() const; bool empty() const; void clear();
};

// --- Lista de Corridas ---
struct NoCorrida {
    Corrida* dado; // Ponteiro
    NoCorrida* proximo;
    NoCorrida(Corrida* c);
};
class ListaCorrida {
private:
    NoCorrida* inicio; NoCorrida* fim; int tamanho;
public:
    ListaCorrida(); ~ListaCorrida();
    void push_back(Corrida* c); Corrida* get(int index);
    int size() const; bool empty() const; void clear(); 
};

#endif // LISTAS_H