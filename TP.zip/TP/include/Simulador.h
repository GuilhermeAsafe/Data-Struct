#ifndef SIMULADOR_H
#define SIMULADOR_H

#include "Motor.h"    
#include "Listas.h"   

class Simulador {
private:
    int eta; // Capacidade (inteiro)
    double gama, delta, alfa, beta, lambda;

    Escalonador escalonador;
    ListaDemanda listaDeTodasDemandas;
    ListaCorrida listaDeTodasCorridas; 
    bool* demandasProcessadas; 
    int numTotalDemandas;

public:
    Simulador();
    ~Simulador(); 

    void carregarEntrada(const char* nomeArquivo);
    void processarDemandas();
    void executar();

private:
    void processarEvento(Evento* evento);
};

#endif // SIMULADOR_H