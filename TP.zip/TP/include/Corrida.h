#ifndef CORRIDA_H
#define CORRIDA_H

#include "Listas.h"
#include "Dominio.h"

class Corrida {
private:
    double gama_velocidade; 
    void reconstruirRota(); 

public:
    ListaDemanda demandasAtendidas;
    ListaTrecho trechos;
    ListaParada paradas; 

    double distanciaTotal;
    double tempoTotal;
    double eficiencia;
    int numeroParadas;

    Corrida(double gama);
    ~Corrida(); 

    void adicionarDemanda(Demanda* demanda);
    void removerUltimaDemanda();
    void calcularEficiencia();
};

#endif // CORRIDA_H