#ifndef DOMINIO_H
#define DOMINIO_H

#include <cmath> 

// --- Coordenada ---
struct Coordenada {
    double x; // CORRIGIDO PARA DOUBLE
    double y; // CORRIGIDO PARA DOUBLE
    
    Coordenada(double x_val = 0.0, double y_val = 0.0); // CORRIGIDO
    double distancia(const Coordenada& outra) const;
};

// --- Demanda ---
enum EstadoDemanda {
    DEMANDADA, INDIVIDUAL, COMBINADA, CONCLUIDA
};

class Demanda {
public:
    int id;
    int tempo; // Tempo é lido como inteiro
    Coordenada origem;
    Coordenada destino;
    EstadoDemanda estado;

    Demanda(int id, int tempo, Coordenada origem, Coordenada destino);
    double getDistanciaIdeal() const;
};

// --- Parada ---
enum TipoParada {
    EMBARQUE, DESEMBARQUE
};

class Parada {
public:
    Coordenada localizacao;
    TipoParada tipo;
    Demanda* passageiro; 

    Parada(); 
    Parada(Coordenada loc, TipoParada tipo, Demanda* passageiro);
};

// --- Trecho ---
enum TipoTrecho {
    COLETA, ENTREGA, DESLOCAMENTO
};

class Trecho {
public:
    Parada* paradaOrigem;
    Parada* paradaDestino;
    double distancia;
    double tempoGasto;
    TipoTrecho natureza;

    Trecho(); 
    Trecho(Parada* origem, Parada* destino, double gama_velocidade);
    void definirNatureza();
};

#endif // DOMINIO_H