#include "Simulador.h"
#include "Corrida.h" 
#include <iostream>
#include <fstream>
#include <iomanip> 

Simulador::Simulador() 
    : eta(0), gama(0.0), delta(0.0), alfa(0.0), beta(0.0), lambda(0.0),
      demandasProcessadas(nullptr), numTotalDemandas(0)
{
    // Construtor
}

Simulador::~Simulador() {
    // Destrutor
    for (int i = 0; i < listaDeTodasDemandas.size(); ++i) {
        delete listaDeTodasDemandas.get(i);
    }
    for (int i = 0; i < listaDeTodasCorridas.size(); ++i) {
        delete listaDeTodasCorridas.get(i);
    }
    if (demandasProcessadas != nullptr) {
        delete[] demandasProcessadas;
    }
}

void Simulador::carregarEntrada(const char* nomeArquivo) {
    std::ifstream arquivo(nomeArquivo);
    if (!arquivo.is_open()) {
        std::cerr << "Erro: Não foi possível abrir o arquivo de entrada: " << nomeArquivo << std::endl;
        return;
    }

    // eta é int, o resto é double
    arquivo >> this->eta;
    arquivo >> this->gama;
    arquivo >> this->delta;
    arquivo >> this->alfa;
    arquivo >> this->beta;
    arquivo >> this->lambda;
    arquivo >> this->numTotalDemandas;
    
    this->demandasProcessadas = new bool[numTotalDemandas];
    for (int i = 0; i < numTotalDemandas; ++i) {
        demandasProcessadas[i] = false;
    }

    for (int i = 0; i < numTotalDemandas; ++i) {
        int id, tempo;
        double ox, oy, dx, dy; // CORRIGIDO PARA DOUBLE
        
        arquivo >> id >> tempo >> ox >> oy >> dx >> dy;
        
        Coordenada origem(ox, oy);
        Coordenada destino(dx, dy);
        
        Demanda* novaDemanda = new Demanda(id, tempo, origem, destino);
        listaDeTodasDemandas.push_back(novaDemanda);
    }
    
    arquivo.close();
    std::cout << std::fixed << std::setprecision(2);
}

void Simulador::processarDemandas() {
    // --- FASE 1: Construção das Corridas ---
    
    for (int i = 0; i < numTotalDemandas; ++i) {
        
        if (demandasProcessadas[i]) {
            continue;
        }

        Demanda* c0 = listaDeTodasDemandas.get(i);
        demandasProcessadas[i] = true; 

        Corrida* novaCorrida = new Corrida(this->gama);
        novaCorrida->adicionarDemanda(c0); 
        
        for (int j = i + 1; j < numTotalDemandas; ++j) {
            
            if (demandasProcessadas[j]) {
                continue;
            }

            Demanda* ci = listaDeTodasDemandas.get(j);

            // Critérios de parada
            if (ci->tempo - c0->tempo >= this->delta) { break; }
            if (novaCorrida->demandasAtendidas.size() >= this->eta) { break; }

            // Critério de Origens
            bool origensOk = true;
            for (int k = 0; k < novaCorrida->demandasAtendidas.size(); ++k) {
                if (ci->origem.distancia(novaCorrida->demandasAtendidas.get(k)->origem) >= this->alfa) {
                    origensOk = false;
                    break;
                }
            }
            if (!origensOk) { break; } // Interrompe avaliação

            // Critério de Destinos
            bool destinosOk = true;
            for (int k = 0; k < novaCorrida->demandasAtendidas.size(); ++k) {
                if (ci->destino.distancia(novaCorrida->demandasAtendidas.get(k)->destino) >= this->beta) {
                    destinosOk = false;
                    break;
                }
            }
            if (!destinosOk) { break; } // Interrompe avaliação

            // Critério de Eficiência
            novaCorrida->adicionarDemanda(ci); 
            if (novaCorrida->eficiencia <= this->lambda) {
                novaCorrida->removerUltimaDemanda();
                break; 
            } else {
                demandasProcessadas[j] = true;
            }
        } 

        listaDeTodasCorridas.push_back(novaCorrida);

        // Agendamento do primeiro evento
        if (novaCorrida->trechos.size() > 0) {
            Trecho& primeiroTrecho = novaCorrida->trechos.get(0);
            double tempoInicio = novaCorrida->demandasAtendidas.get(0)->tempo;
            double tempoChegada = tempoInicio + primeiroTrecho.tempoGasto;
            
            Evento* primeiroEvento = new Evento(tempoChegada, CHEGADA_PARADA, novaCorrida, 0);
            escalonador.InsereEvento(primeiroEvento);
        }
    } 
}

void Simulador::executar() {
    // --- FASE 2: Loop de Simulação ---
    while (!escalonador.estaVazio()) {
        Evento* eventoAtual = escalonador.RetiraProximoEvento();
        processarEvento(eventoAtual);
        delete eventoAtual; 
    }
}

void Simulador::processarEvento(Evento* evento) {
    Corrida* corrida = evento->corrida;
    int indiceTrechoConcluido = evento->indiceTrecho;

    if (indiceTrechoConcluido == corrida->trechos.size() - 1) {
        // --- É O ÚLTIMO EVENTO DA CORRIDA ---
        std::cout << evento->tempo << " ";
        std::cout << corrida->distanciaTotal << " ";
        std::cout << corrida->numeroParadas << " ";

        // Imprime a primeira parada
        std::cout << corrida->trechos.get(0).paradaOrigem->localizacao.x << " "
                  << corrida->trechos.get(0).paradaOrigem->localizacao.y;
        
        // Imprime as demais paradas
        for (int i = 0; i < corrida->trechos.size(); ++i) {
            std::cout << " " << corrida->trechos.get(i).paradaDestino->localizacao.x
                      << " " << corrida->trechos.get(i).paradaDestino->localizacao.y;
        }
        std::cout << std::endl; 

    } else {
        // --- NÃO É O ÚLTIMO EVENTO ---
        int indiceProximoTrecho = indiceTrechoConcluido + 1;
        Trecho& proximoTrecho = corrida->trechos.get(indiceProximoTrecho);
        
        double tempoProximoEvento = evento->tempo + proximoTrecho.tempoGasto;
        
        Evento* proximoEvento = new Evento(tempoProximoEvento, CHEGADA_PARADA, corrida, indiceProximoTrecho);
        escalonador.InsereEvento(proximoEvento);
    }
}