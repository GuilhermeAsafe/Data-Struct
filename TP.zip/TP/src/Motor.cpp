#include "Motor.h"
#include <stdexcept>

// --- Evento ---
Evento::Evento(double t, TipoEvento tp, Corrida* c, int indice)
    : tempo(t), tipo(tp), corrida(c), indiceTrecho(indice) 
{}

bool Evento::operator>(const Evento& outro) const {
    return this->tempo > outro.tempo;
}

// --- MinHeap ---
MinHeap::MinHeap() : capacidade(10), tamanho(0) {
    dados = new Evento*[capacidade];
}

MinHeap::~MinHeap() {
    for (int i = 0; i < tamanho; ++i) {
        delete dados[i];
    }
    delete[] dados;
}

void MinHeap::redimensionar() {
    capacidade *= 2;
    Evento** novosDados = new Evento*[capacidade];
    for (int i = 0; i < tamanho; ++i) {
        novosDados[i] = dados[i];
    }
    delete[] dados;
    dados = novosDados;
}

void MinHeap::swap(int i, int j) {
    Evento* temp = dados[i];
    dados[i] = dados[j];
    dados[j] = temp;
}

void MinHeap::heapifyUp(int index) {
    while (index > 0 && (*dados[index] > *dados[getParent(index)] == false)) {
        swap(index, getParent(index));
        index = getParent(index);
    }
}

void MinHeap::heapifyDown(int index) {
    int left = getLeftChild(index);
    int right = getRightChild(index);
    int menor = index;

    if (left < tamanho && (*dados[left] > *dados[menor] == false)) {
        menor = left;
    }
    if (right < tamanho && (*dados[right] > *dados[menor] == false)) {
        menor = right;
    }

    if (menor != index) {
        swap(index, menor);
        heapifyDown(menor);
    }
}

void MinHeap::inserir(Evento* evento) {
    if (tamanho == capacidade) {
        redimensionar();
    }
    dados[tamanho] = evento;
    tamanho++;
    heapifyUp(tamanho - 1);
}

Evento* MinHeap::removerMin() {
    if (estaVazio()) {
        return nullptr;
    }
    Evento* minEvento = dados[0];
    dados[0] = dados[tamanho - 1];
    tamanho--;
    
    if (tamanho > 0) {
        heapifyDown(0);
    }
    
    return minEvento;
}

bool MinHeap::estaVazio() const {
    return tamanho == 0;
}

// --- Escalonador ---
Escalonador::Escalonador() {}
Escalonador::~Escalonador() {}

void Escalonador::InsereEvento(Evento* evento) {
    heap.inserir(evento);
}

Evento* Escalonador::RetiraProximoEvento() {
    return heap.removerMin();
}

bool Escalonador::estaVazio() const {
    return heap.estaVazio();
}