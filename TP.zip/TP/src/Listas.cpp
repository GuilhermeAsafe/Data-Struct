#include "Listas.h"
#include "Corrida.h" 
#include <stdexcept>

// --- Lista de Demandas ---
NoDemanda::NoDemanda(Demanda* d) : dado(d), proximo(nullptr) {}
ListaDemanda::ListaDemanda() : inicio(nullptr), fim(nullptr), tamanho(0) {}
ListaDemanda::~ListaDemanda() { clear(); }
void ListaDemanda::push_back(Demanda* d) {
    NoDemanda* novoNo = new NoDemanda(d);
    if (empty()) { inicio = novoNo; fim = novoNo; }
    else { fim->proximo = novoNo; fim = novoNo; }
    tamanho++;
}
Demanda* ListaDemanda::get(int index) {
    if (index < 0 || index >= tamanho) { throw std::out_of_range("Índice ListaDemanda"); }
    NoDemanda* atual = inicio;
    for (int i = 0; i < index; ++i) { atual = atual->proximo; }
    return atual->dado;
}
Demanda* ListaDemanda::pop_back() {
    if (empty()) { throw std::out_of_range("pop_back() ListaDemanda"); }
    Demanda* dadoRemovido = fim->dado;
    if (tamanho == 1) { delete inicio; inicio = nullptr; fim = nullptr; }
    else {
        NoDemanda* atual = inicio;
        while (atual->proximo != fim) { atual = atual->proximo; }
        delete fim; fim = atual; fim->proximo = nullptr;
    }
    tamanho--; return dadoRemovido;
}
int ListaDemanda::size() const { return tamanho; }
bool ListaDemanda::empty() const { return tamanho == 0; }
void ListaDemanda::clear() {
    NoDemanda* atual = inicio;
    while (atual != nullptr) {
        NoDemanda* proximo = atual->proximo;
        delete atual; atual = proximo;
    }
    inicio = nullptr; fim = nullptr; tamanho = 0;
}

// --- Lista de Trechos ---
NoTrecho::NoTrecho(Trecho t) : dado(t), proximo(nullptr) {}
ListaTrecho::ListaTrecho() : inicio(nullptr), fim(nullptr), tamanho(0) {}
ListaTrecho::~ListaTrecho() { clear(); }
void ListaTrecho::push_back(Trecho t) {
    NoTrecho* novoNo = new NoTrecho(t);
    if (empty()) { inicio = novoNo; fim = novoNo; }
    else { fim->proximo = novoNo; fim = novoNo; }
    tamanho++;
}
Trecho& ListaTrecho::get(int index) {
    if (index < 0 || index >= tamanho) { throw std::out_of_range("Índice ListaTrecho"); }
    NoTrecho* atual = inicio;
    for (int i = 0; i < index; ++i) { atual = atual->proximo; }
    return atual->dado;
}
int ListaTrecho::size() const { return tamanho; }
bool ListaTrecho::empty() const { return tamanho == 0; }
void ListaTrecho::clear() {
    NoTrecho* atual = inicio;
    while (atual != nullptr) {
        NoTrecho* proximo = atual->proximo;
        delete atual; atual = proximo;
    }
    inicio = nullptr; fim = nullptr; tamanho = 0;
}

// --- Lista de Paradas ---
NoParada::NoParada(Parada p) : dado(p), proximo(nullptr) {}
ListaParada::ListaParada() : inicio(nullptr), fim(nullptr), tamanho(0) {}
ListaParada::~ListaParada() { clear(); }
void ListaParada::push_back(Parada p) {
    NoParada* novoNo = new NoParada(p);
    if (empty()) { inicio = novoNo; fim = novoNo; }
    else { fim->proximo = novoNo; fim = novoNo; }
    tamanho++;
}
Parada* ListaParada::get(int index) {
    if (index < 0 || index >= tamanho) { throw std::out_of_range("Índice ListaParada"); }
    NoParada* atual = inicio;
    for (int i = 0; i < index; ++i) { atual = atual->proximo; }
    return &(atual->dado);
}
int ListaParada::size() const { return tamanho; }
bool ListaParada::empty() const { return tamanho == 0; }
void ListaParada::clear() {
    NoParada* atual = inicio;
    while (atual != nullptr) {
        NoParada* proximo = atual->proximo;
        delete atual; atual = proximo;
    }
    inicio = nullptr; fim = nullptr; tamanho = 0;
}

// --- Lista de Corridas ---
NoCorrida::NoCorrida(Corrida* c) : dado(c), proximo(nullptr) {}
ListaCorrida::ListaCorrida() : inicio(nullptr), fim(nullptr), tamanho(0) {}
ListaCorrida::~ListaCorrida() { clear(); }
void ListaCorrida::push_back(Corrida* c) {
    NoCorrida* novoNo = new NoCorrida(c);
    if (empty()) { inicio = novoNo; fim = novoNo; }
    else { fim->proximo = novoNo; fim = novoNo; }
    tamanho++;
}
Corrida* ListaCorrida::get(int index) {
    if (index < 0 || index >= tamanho) { throw std::out_of_range("Índice ListaCorrida"); }
    NoCorrida* atual = inicio;
    for (int i = 0; i < index; ++i) { atual = atual->proximo; }
    return atual->dado;
}
int ListaCorrida::size() const { return tamanho; }
bool ListaCorrida::empty() const { return tamanho == 0; }
void ListaCorrida::clear() {
    NoCorrida* atual = inicio;
    while (atual != nullptr) {
        NoCorrida* proximo = atual->proximo;
        delete atual; atual = proximo;
    }
    inicio = nullptr; fim = nullptr; tamanho = 0;
}