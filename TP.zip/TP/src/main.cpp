#include <iostream>  
#include <iomanip>   
#include <stdexcept> 
#include "Simulador.h" 

int main(int argc, char* argv[]) {
    
    if (argc != 2) {
        std::cerr << "Erro: Uso incorreto." << std::endl;
        std::cerr << "Uso: ./bin/tp2.out <arquivo_de_entrada>" << std::endl;
        return 1; 
    }

    const char* arquivoEntrada = argv[1];

    try {
        Simulador simulador;
        simulador.carregarEntrada(arquivoEntrada);
        simulador.processarDemandas();
        simulador.executar();

    } catch (const std::exception& e) {
        std::cerr << "Erro inesperado durante a execução: " << e.what() << std::endl;
        return 2; 
    }

    return 0;
}