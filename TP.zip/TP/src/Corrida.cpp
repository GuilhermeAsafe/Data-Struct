#include "Corrida.h"
#include <stdexcept>

Corrida::Corrida(double gama)
    : gama_velocidade(gama),
      distanciaTotal(0.0), 
      tempoTotal(0.0), 
      eficiencia(1.0), 
      numeroParadas(0)
{}

Corrida::~Corrida() {
    demandasAtendidas.clear();
    trechos.clear();
    paradas.clear();
}

void Corrida::reconstruirRota() {
    trechos.clear();
    paradas.clear();
    distanciaTotal = 0.0;
    tempoTotal = 0.0;
    numeroParadas = 0;

    int numDemandas = demandasAtendidas.size();
    if (numDemandas == 0) {
        eficiencia = 1.0; 
        return;
    }

    // Cria a lista de Paradas
    for (int i = 0; i < numDemandas; ++i) {
        Demanda* d = demandasAtendidas.get(i);
        paradas.push_back(Parada(d->origem, EMBARQUE, d));
    }
    for (int i = 0; i < numDemandas; ++i) {
        Demanda* d = demandasAtendidas.get(i);
        paradas.push_back(Parada(d->destino, DESEMBARQUE, d));
    }

    this->numeroParadas = paradas.size();

    // Cria os Trechos
    for (int i = 0; i < this->numeroParadas - 1; ++i) {
        Parada* pOrigem = paradas.get(i);
        Parada* pDestino = paradas.get(i + 1);
        
        Trecho novoTrecho(pOrigem, pDestino, this->gama_velocidade);
        trechos.push_back(novoTrecho);
        
        distanciaTotal += novoTrecho.distancia;
        tempoTotal += novoTrecho.tempoGasto;
    }

    calcularEficiencia();
}

void Corrida::adicionarDemanda(Demanda* demanda) {
    demandasAtendidas.push_back(demanda);
    reconstruirRota();
}

void Corrida::removerUltimaDemanda() {
    demandasAtendidas.pop_back(); 
    reconstruirRota(); 
}

void Corrida::calcularEficiencia() {
    if (demandasAtendidas.empty() || distanciaTotal == 0.0) {
        this->eficiencia = 1.0; 
        return;
    }

    double distanciaIdealSoma = 0.0;
    for (int i = 0; i < demandasAtendidas.size(); ++i) {
        distanciaIdealSoma += demandasAtendidas.get(i)->getDistanciaIdeal();
    }

    this->eficiencia = distanciaIdealSoma / this->distanciaTotal;
}